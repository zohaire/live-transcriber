# Live Interpreter Transcriber — Android MVP

A small Android app for interpreters who want to keep source audio in their headphones while seeing their own speech transcribed live.

## What version 1 does

- Detects wired, USB, classic Bluetooth, and BLE audio output devices.
- Uses Android's built-in `SpeechRecognizer` — no API key is required.
- Shows partial transcription while you speak.
- Restarts recognition automatically after pauses to approximate continuous dictation.
- Arabic mode (`ar-MA`).
- English mode (`en-US`).
- Auto Arabic/English detection and switching on Android 14+ when the installed recognition service supports it.
- Copy, clear, and save transcript as UTF-8 `.txt`.
- Does not request media audio focus, so your source audio can remain in another app/headphones.

## Requirements

- Android Studio with Android 16 / API 36 SDK installed.
- JDK 17 (Android Studio includes a compatible JDK).
- A physical Android phone is strongly recommended for microphone/headphone testing.

## Run it

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. If Android Studio asks for SDK 36, install it with **Tools > SDK Manager**.
4. Connect your Android phone with USB debugging enabled.
5. Press **Run**.
6. Grant microphone permission.
7. Connect your headphones, play your source audio, then tap **Start transcription**.

## Important Bluetooth note

Android controls the active microphone route used by the speech recognition service. With some Bluetooth headsets, opening the headset microphone can switch the Bluetooth profile and reduce playback quality. Wired headphones are the easiest first test. If we need guaranteed "high-quality Bluetooth output + phone built-in microphone" routing, version 2 should use `AudioRecord` plus a streaming transcription engine instead of relying only on `SpeechRecognizer`.

## Project architecture

The MVP intentionally uses only Android platform APIs and a single Java activity. This makes it easy to open, understand, and modify without extra UI or networking libraries.

## Gradle note

The project includes `gradle/wrapper/gradle-wrapper.properties` pinned to Gradle 8.13. Open it in Android Studio and sync with the wrapper distribution. The ZIP intentionally does not include the small binary `gradle-wrapper.jar`; Android Studio can use the wrapper configuration when importing. If your IDE specifically requires the wrapper JAR for command-line `./gradlew`, choose **Gradle > Wrapper** / regenerate the wrapper from Android Studio after opening the project.
