# Interpreter Trainer — Version 2.0

A mobile interpreting practice app for Arabic, English and French.

## Training modes

- **Sight Translation** — import a document or paste text, keep the source visible, and transcribe your interpretation live.
- **Shadowing** — import audio/video, change playback speed, listen through headphones and transcribe your shadowing live.
- **Consecutive Interpretation** — play 15/30/60-second source segments, take notes, then transcribe the interpretation.

## Document import

Supported directly in the app:

- PDF
- DOCX (modern Microsoft Word)
- TXT
- RTF
- HTML / HTM
- CSV
- Markdown
- JSON
- XML
- Other UTF-8 text-based documents (best effort)

PDF text extraction uses PdfBox-Android. Scanned/image-only PDFs require OCR and may not contain extractable text.

## Other features

- Arabic, English and French transcription
- Auto language detection/switching on supported Android 14+ recognizers
- Bluetooth/wired/USB headphone detection
- Dark professional interface
- Custom app icon and Android 12+ splash screen
- Training dashboard with sessions, minutes, words and a 30-minute practice goal
- Save/copy/clear transcript
- Consecutive notes area
- Audio playback speed: 0.75× / 1.0× / 1.25×

## Build

The existing GitHub Actions workflow can build this project with `gradle assembleDebug`.
