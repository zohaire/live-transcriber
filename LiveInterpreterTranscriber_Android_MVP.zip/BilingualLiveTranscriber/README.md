# Interpreter Live Transcriber v1.1

Android app for interpreter practice.

## Features
- Live speech transcription in Arabic (Morocco), English (US), and French (France)
- Auto language detection/switching on supported Android 14+ recognition services
- Headphone connection status
- Practice Text area for sight translation
- Paste text directly into the app
- Import UTF-8 `.txt` files
- Receive shared plain text from other Android apps
- Independent scrolling for source text and transcript
- Source text size controls
- Copy, clear, and save transcript as `.txt`

The app uses Android's built-in SpeechRecognizer and therefore recognition quality/availability depends on the speech service installed on the phone.
