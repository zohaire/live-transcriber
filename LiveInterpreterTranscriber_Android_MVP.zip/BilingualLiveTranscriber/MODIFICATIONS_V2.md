# Interpreter Trainer — Complete V2 Modification List

## Visual identity
- New application name: **Interpreter Trainer**
- New vector app icon built into the APK
- Android 12+ splash screen
- Dark navy professional interpreting-booth theme
- Gold accent color, blue secondary accent, modern cards and large mode controls

## Languages
- Arabic (`ar-MA`)
- English (`en-US`)
- French (`fr-FR`)
- Auto language detection/switching on compatible Android 14+ speech recognizers

## Sight Translation
- Dedicated Sight mode
- Import document button
- Paste text button
- Independent scrollable source-text area
- Font-size controls
- Live interpretation transcript stays visible below
- Source filename indicator

## Document import
Direct extraction is included for:
- PDF
- DOCX (modern Word documents)
- TXT
- RTF
- HTML / HTM
- CSV
- Markdown
- JSON
- XML
- Other UTF-8 text-based files (best effort)

Notes:
- Scanned/image-only PDFs do not contain normal extractable text; OCR would be a separate future module.
- Old binary `.doc` files are not guaranteed. Saving them as `.docx` is recommended.

## Shadowing
- Dedicated Shadowing mode
- Import common audio or video files
- Play / pause / restart source media
- Playback speed: 0.75×, 1.0×, 1.25×
- Live speech transcription while source media plays through headphones

## Consecutive Interpretation
- Dedicated Consecutive mode
- Source audio/video import
- 15-second, 30-second and 60-second segment controls
- “Play next segment” workflow
- Automatic pause at the end of each segment
- Interpreter notes area
- Live interpretation transcription
- Session save includes notes + transcript

## Training dashboard
- Total practice sessions
- Total practice minutes
- Total transcribed words
- 30-minute practice-goal progress bar
- Counts stored locally on the phone

## Existing features retained
- Wired / Bluetooth / USB headphone detection
- Continuous-style Android speech recognition with automatic restart after pauses
- Live partial transcription
- Copy transcript
- Clear transcript
- Save session as `.txt`
