package com.example.bilingualtranscriber;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements RecognitionListener {

    private static final int REQUEST_RECORD_AUDIO = 1001;
    private static final int REQUEST_SAVE_FILE = 1002;

    private enum LanguageMode { AUTO, ARABIC, ENGLISH }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder committedText = new StringBuilder();

    private SpeechRecognizer speechRecognizer;
    private AudioManager audioManager;
    private AudioDeviceCallback audioDeviceCallback;
    private boolean audioCallbackRegistered = false;
    private boolean shouldListen = false;
    private boolean recognitionInProgress = false;
    private LanguageMode languageMode = LanguageMode.AUTO;

    private TextView headsetStatus;
    private TextView recognitionStatus;
    private TextView detectedLanguage;
    private TextView transcriptView;
    private TextView partialView;
    private Button startStopButton;
    private Button autoButton;
    private Button arabicButton;
    private Button englishButton;

    private final Runnable restartRecognition = new Runnable() {
        @Override
        public void run() {
            if (shouldListen && !recognitionInProgress) {
                startRecognitionCycle();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        buildUi();
        setupAudioDeviceMonitoring();
        refreshHeadsetStatus();
        refreshLanguageButtons();

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            recognitionStatus.setText("Speech recognition is not available on this phone.");
            startStopButton.setEnabled(false);
        } else {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(this);
        }
    }

    private void buildUi() {
        int pad = dp(20);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(247, 248, 250));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(22), pad, dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("Live Interpreter Transcriber");
        title.setTextSize(27);
        title.setTextColor(Color.rgb(20, 24, 31));
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Listen through your headphones while your speech is transcribed live in Arabic or English.");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.rgb(91, 99, 112));
        subtitle.setPadding(0, dp(8), 0, dp(18));
        root.addView(subtitle);

        LinearLayout statusCard = card();
        root.addView(statusCard, matchWrapWithBottomMargin(dp(14)));

        headsetStatus = statusText("Checking headphones…");
        statusCard.addView(headsetStatus);

        recognitionStatus = statusText("Ready");
        recognitionStatus.setPadding(0, dp(8), 0, 0);
        statusCard.addView(recognitionStatus);

        detectedLanguage = statusText("Detected language: —");
        detectedLanguage.setPadding(0, dp(8), 0, 0);
        statusCard.addView(detectedLanguage);

        TextView modeLabel = sectionLabel("LANGUAGE");
        root.addView(modeLabel);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeRow.setGravity(Gravity.CENTER);
        root.addView(modeRow, matchWrapWithBottomMargin(dp(18)));

        autoButton = smallButton("Auto");
        arabicButton = smallButton("العربية");
        englishButton = smallButton("English");
        modeRow.addView(autoButton, weightedButtonParams());
        modeRow.addView(arabicButton, weightedButtonParamsWithStartMargin());
        modeRow.addView(englishButton, weightedButtonParamsWithStartMargin());

        autoButton.setOnClickListener(v -> setLanguageMode(LanguageMode.AUTO));
        arabicButton.setOnClickListener(v -> setLanguageMode(LanguageMode.ARABIC));
        englishButton.setOnClickListener(v -> setLanguageMode(LanguageMode.ENGLISH));

        startStopButton = new Button(this);
        startStopButton.setAllCaps(false);
        startStopButton.setText("Start transcription");
        startStopButton.setTextSize(17);
        startStopButton.setTextColor(Color.WHITE);
        startStopButton.setBackground(rounded(Color.rgb(28, 113, 74), 16));
        startStopButton.setPadding(dp(16), dp(12), dp(16), dp(12));
        root.addView(startStopButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));
        startStopButton.setOnClickListener(v -> toggleListening());

        TextView transcriptLabel = sectionLabel("TRANSCRIPT");
        transcriptLabel.setPadding(0, dp(22), 0, dp(8));
        root.addView(transcriptLabel);

        LinearLayout transcriptCard = card();
        transcriptCard.setMinimumHeight(dp(260));
        root.addView(transcriptCard, matchWrapWithBottomMargin(dp(14)));

        transcriptView = new TextView(this);
        transcriptView.setText("Your transcript will appear here.");
        transcriptView.setTextSize(19);
        transcriptView.setTextColor(Color.rgb(25, 29, 36));
        transcriptView.setLineSpacing(0, 1.25f);
        transcriptView.setTextIsSelectable(true);
        transcriptCard.addView(transcriptView);

        partialView = new TextView(this);
        partialView.setText("");
        partialView.setTextSize(18);
        partialView.setTextColor(Color.rgb(120, 126, 136));
        partialView.setPadding(0, dp(12), 0, 0);
        transcriptCard.addView(partialView);

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actionRow);

        Button copyButton = smallButton("Copy");
        Button clearButton = smallButton("Clear");
        Button saveButton = smallButton("Save .txt");
        actionRow.addView(copyButton, weightedButtonParams());
        actionRow.addView(clearButton, weightedButtonParamsWithStartMargin());
        actionRow.addView(saveButton, weightedButtonParamsWithStartMargin());

        copyButton.setOnClickListener(v -> copyTranscript());
        clearButton.setOnClickListener(v -> clearTranscript());
        saveButton.setOnClickListener(v -> beginSaveTranscript());

        TextView note = new TextView(this);
        note.setText("Tip: keep the source audio playing through your headphones. This app does not request media audio focus, so it only listens for speech through Android's active microphone route.");
        note.setTextSize(13);
        note.setTextColor(Color.rgb(103, 109, 120));
        note.setPadding(0, dp(18), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(16), dp(18), dp(16));
        layout.setBackground(rounded(Color.WHITE, 18));
        return layout;
    }

    private TextView sectionLabel(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(12);
        view.setTextColor(Color.rgb(105, 111, 122));
        view.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        view.setPadding(0, 0, 0, dp(8));
        return view;
    }

    private TextView statusText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(14);
        view.setTextColor(Color.rgb(69, 76, 88));
        return view;
    }

    private Button smallButton(String text) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(text);
        button.setTextSize(14);
        button.setTextColor(Color.rgb(45, 51, 61));
        button.setBackground(rounded(Color.WHITE, 14));
        button.setPadding(dp(8), dp(8), dp(8), dp(8));
        return button;
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        return new LinearLayout.LayoutParams(0, dp(50), 1f);
    }

    private LinearLayout.LayoutParams weightedButtonParamsWithStartMargin() {
        LinearLayout.LayoutParams params = weightedButtonParams();
        params.setMarginStart(dp(8));
        return params;
    }

    private LinearLayout.LayoutParams matchWrapWithBottomMargin(int bottomMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = bottomMargin;
        return params;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void setLanguageMode(LanguageMode mode) {
        languageMode = mode;
        detectedLanguage.setText("Detected language: —");
        refreshLanguageButtons();

        if (shouldListen) {
            if (speechRecognizer != null) {
                speechRecognizer.cancel();
            }
            recognitionInProgress = false;
            handler.removeCallbacks(restartRecognition);
            handler.postDelayed(restartRecognition, 250);
        }
    }

    private void refreshLanguageButtons() {
        styleModeButton(autoButton, languageMode == LanguageMode.AUTO);
        styleModeButton(arabicButton, languageMode == LanguageMode.ARABIC);
        styleModeButton(englishButton, languageMode == LanguageMode.ENGLISH);
    }

    private void styleModeButton(Button button, boolean selected) {
        if (button == null) return;
        if (selected) {
            button.setTextColor(Color.WHITE);
            button.setBackground(rounded(Color.rgb(39, 90, 164), 14));
        } else {
            button.setTextColor(Color.rgb(45, 51, 61));
            button.setBackground(rounded(Color.WHITE, 14));
        }
    }

    private void toggleListening() {
        if (shouldListen) {
            stopListening();
        } else {
            ensurePermissionAndStart();
        }
    }

    private void ensurePermissionAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
        }
    }

    private void startListening() {
        if (speechRecognizer == null) return;
        shouldListen = true;
        startStopButton.setText("Stop transcription");
        startStopButton.setBackground(rounded(Color.rgb(173, 55, 55), 16));
        recognitionStatus.setText("Starting…");
        handler.removeCallbacks(restartRecognition);
        startRecognitionCycle();
    }

    private void stopListening() {
        shouldListen = false;
        recognitionInProgress = false;
        handler.removeCallbacks(restartRecognition);
        if (speechRecognizer != null) {
            try {
                speechRecognizer.stopListening();
            } catch (Exception ignored) {
            }
        }
        partialView.setText("");
        recognitionStatus.setText("Paused");
        startStopButton.setText("Start transcription");
        startStopButton.setBackground(rounded(Color.rgb(28, 113, 74), 16));
    }

    private void startRecognitionCycle() {
        if (!shouldListen || speechRecognizer == null || recognitionInProgress) return;

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);

        if (Build.VERSION.SDK_INT >= 33) {
            intent.putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING, RecognizerIntent.FORMATTING_OPTIMIZE_LATENCY);
            intent.putExtra(RecognizerIntent.EXTRA_HIDE_PARTIAL_TRAILING_PUNCTUATION, true);
        }

        if (languageMode == LanguageMode.ARABIC) {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-MA");
        } else if (languageMode == LanguageMode.ENGLISH) {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        } else {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-MA");
            if (Build.VERSION.SDK_INT >= 34) {
                ArrayList<String> languages = new ArrayList<>();
                languages.add("ar-MA");
                languages.add("en-US");
                intent.putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION, true);
                intent.putStringArrayListExtra(RecognizerIntent.EXTRA_LANGUAGE_DETECTION_ALLOWED_LANGUAGES, languages);
                intent.putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_SWITCH, RecognizerIntent.LANGUAGE_SWITCH_BALANCED);
                intent.putStringArrayListExtra(RecognizerIntent.EXTRA_LANGUAGE_SWITCH_ALLOWED_LANGUAGES, languages);
            }
        }

        try {
            recognitionInProgress = true;
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            recognitionInProgress = false;
            recognitionStatus.setText("Could not start recognition: " + e.getMessage());
            scheduleRestart(700);
        }
    }

    private void scheduleRestart(long delayMs) {
        if (!shouldListen) return;
        handler.removeCallbacks(restartRecognition);
        handler.postDelayed(restartRecognition, delayMs);
    }

    private void appendFinalText(String text) {
        if (text == null || text.trim().isEmpty()) return;
        if (committedText.length() > 0) {
            committedText.append('\n');
        }
        committedText.append(text.trim());
        transcriptView.setText(committedText.toString());
        partialView.setText("");
    }

    private void clearTranscript() {
        committedText.setLength(0);
        transcriptView.setText("Your transcript will appear here.");
        partialView.setText("");
    }

    private void copyTranscript() {
        if (committedText.length() == 0) {
            Toast.makeText(this, "Nothing to copy yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Transcript", committedText.toString()));
        Toast.makeText(this, "Transcript copied.", Toast.LENGTH_SHORT).show();
    }

    private void beginSaveTranscript() {
        if (committedText.length() == 0) {
            Toast.makeText(this, "Nothing to save yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "transcript_" + stamp + ".txt");
        startActivityForResult(intent, REQUEST_SAVE_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SAVE_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
                if (stream != null) {
                    stream.write(committedText.toString().getBytes(StandardCharsets.UTF_8));
                    stream.flush();
                    Toast.makeText(this, "Transcript saved.", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void setupAudioDeviceMonitoring() {
        if (Build.VERSION.SDK_INT >= 23) {
            audioDeviceCallback = new AudioDeviceCallback() {
                @Override
                public void onAudioDevicesAdded(AudioDeviceInfo[] addedDevices) {
                    refreshHeadsetStatus();
                }

                @Override
                public void onAudioDevicesRemoved(AudioDeviceInfo[] removedDevices) {
                    refreshHeadsetStatus();
                }
            };
        }
    }

    private void refreshHeadsetStatus() {
        if (audioManager == null) return;
        AudioDeviceInfo[] devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
        String detected = null;

        for (AudioDeviceInfo device : devices) {
            switch (device.getType()) {
                case AudioDeviceInfo.TYPE_WIRED_HEADPHONES:
                    detected = "Wired headphones connected";
                    break;
                case AudioDeviceInfo.TYPE_WIRED_HEADSET:
                    detected = "Wired headset connected";
                    break;
                case AudioDeviceInfo.TYPE_USB_HEADSET:
                    detected = "USB headset connected";
                    break;
                case AudioDeviceInfo.TYPE_BLUETOOTH_A2DP:
                case AudioDeviceInfo.TYPE_BLUETOOTH_SCO:
                    detected = "Bluetooth headphones connected";
                    break;
                default:
                    if (Build.VERSION.SDK_INT >= 31 &&
                            (device.getType() == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                             device.getType() == AudioDeviceInfo.TYPE_BLE_SPEAKER)) {
                        detected = "Bluetooth LE audio connected";
                    }
                    break;
            }
            if (detected != null) break;
        }

        if (detected == null) {
            headsetStatus.setText("Headphones: not detected (transcription still works)");
        } else {
            headsetStatus.setText("Headphones: " + detected);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (audioManager != null && audioDeviceCallback != null && !audioCallbackRegistered) {
            audioManager.registerAudioDeviceCallback(audioDeviceCallback, handler);
            audioCallbackRegistered = true;
        }
        refreshHeadsetStatus();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (audioManager != null && audioDeviceCallback != null && audioCallbackRegistered) {
            audioManager.unregisterAudioDeviceCallback(audioDeviceCallback);
            audioCallbackRegistered = false;
        }
    }

    @Override
    protected void onDestroy() {
        shouldListen = false;
        handler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startListening();
            } else {
                recognitionStatus.setText("Microphone permission is required.");
                if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                    Toast.makeText(this, "Enable Microphone permission in Settings.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                }
            }
        }
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        recognitionStatus.setText("Listening… speak now");
    }

    @Override
    public void onBeginningOfSpeech() {
        recognitionStatus.setText("Transcribing…");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
        // Not needed for the MVP.
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
        // Not needed for the MVP.
    }

    @Override
    public void onEndOfSpeech() {
        recognitionStatus.setText("Processing…");
    }

    @Override
    public void onError(int error) {
        recognitionInProgress = false;

        if (!shouldListen) return;

        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            recognitionStatus.setText("Microphone permission is required.");
            shouldListen = false;
            startStopButton.setText("Start transcription");
            return;
        }

        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            recognitionStatus.setText("Listening…");
            scheduleRestart(250);
            return;
        }

        recognitionStatus.setText("Recognizer reconnecting… (" + errorName(error) + ")");
        scheduleRestart(700);
    }

    @Override
    public void onResults(Bundle results) {
        recognitionInProgress = false;
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) {
            appendFinalText(matches.get(0));
        }
        recognitionStatus.setText("Listening…");
        scheduleRestart(250);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) {
            partialView.setText(matches.get(0));
        }
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
        // Reserved for recognition-service-specific events.
    }

    @Override
    public void onSegmentResults(Bundle segmentResults) {
        // Final text is handled in onResults for broad device compatibility.
    }

    @Override
    public void onEndOfSegmentedSession() {
        // Not using segmented session in this MVP.
    }

    @Override
    public void onLanguageDetection(Bundle results) {
        if (Build.VERSION.SDK_INT < 34 || results == null) return;
        String language = results.getString(SpeechRecognizer.DETECTED_LANGUAGE);
        if (language == null || language.isEmpty()) return;

        String friendly = language;
        if (language.toLowerCase(Locale.ROOT).startsWith("ar")) {
            friendly = "Arabic (" + language + ")";
        } else if (language.toLowerCase(Locale.ROOT).startsWith("en")) {
            friendly = "English (" + language + ")";
        }
        detectedLanguage.setText("Detected language: " + friendly);
    }

    private String errorName(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "audio error";
            case SpeechRecognizer.ERROR_CLIENT: return "client error";
            case SpeechRecognizer.ERROR_NETWORK: return "network error";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "network timeout";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "recognizer busy";
            case SpeechRecognizer.ERROR_SERVER: return "server error";
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED: return "server disconnected";
            case SpeechRecognizer.ERROR_TOO_MANY_REQUESTS: return "too many requests";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: return "language not supported";
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: return "language unavailable";
            default: return "error " + error;
        }
    }
}
