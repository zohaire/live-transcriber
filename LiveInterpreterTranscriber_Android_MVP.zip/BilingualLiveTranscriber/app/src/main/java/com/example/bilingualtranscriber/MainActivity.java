package com.example.bilingualtranscriber;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.Html;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity implements RecognitionListener {

    private static final int REQUEST_RECORD_AUDIO = 1001;
    private static final int REQUEST_SAVE_FILE = 1002;
    private static final int REQUEST_OPEN_DOCUMENT = 1003;
    private static final int REQUEST_OPEN_MEDIA = 1004;

    private static final int BG = Color.rgb(9, 14, 28);
    private static final int CARD = Color.rgb(20, 28, 48);
    private static final int CARD_2 = Color.rgb(27, 37, 61);
    private static final int GOLD = Color.rgb(244, 199, 106);
    private static final int BLUE = Color.rgb(105, 165, 255);
    private static final int TEXT = Color.rgb(246, 248, 252);
    private static final int MUTED = Color.rgb(169, 180, 203);
    private static final int RED = Color.rgb(218, 85, 91);
    private static final int GREEN = Color.rgb(54, 179, 126);

    private enum LanguageMode { AUTO, ARABIC, ENGLISH, FRENCH }
    private enum PracticeMode { SIGHT, SHADOWING, CONSECUTIVE }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder committedText = new StringBuilder();

    private SpeechRecognizer speechRecognizer;
    private AudioManager audioManager;
    private AudioDeviceCallback audioDeviceCallback;
    private boolean audioCallbackRegistered = false;
    private boolean shouldListen = false;
    private boolean recognitionInProgress = false;
    private LanguageMode languageMode = LanguageMode.AUTO;
    private PracticeMode practiceMode = PracticeMode.SIGHT;

    private MediaPlayer mediaPlayer;
    private Uri mediaUri;
    private boolean mediaPrepared = false;
    private float playbackSpeed = 1.0f;
    private int consecutiveChunkSeconds = 30;
    private Runnable pauseMediaRunnable;

    private TextView headsetStatus;
    private TextView recognitionStatus;
    private TextView detectedLanguage;
    private TextView sourceFileLabel;
    private TextView sourceTextView;
    private TextView transcriptView;
    private TextView partialView;
    private TextView mediaFileLabel;
    private TextView mediaStatus;
    private TextView dashboardSessions;
    private TextView dashboardMinutes;
    private TextView dashboardWords;
    private TextView dailyGoalLabel;
    private ProgressBar dailyGoalProgress;
    private EditText consecutiveNotes;

    private Button startStopButton;
    private Button autoButton;
    private Button arabicButton;
    private Button englishButton;
    private Button frenchButton;
    private Button sightButton;
    private Button shadowingButton;
    private Button consecutiveButton;
    private Button playPauseMediaButton;
    private Button speed075Button;
    private Button speed100Button;
    private Button speed125Button;
    private Button chunk15Button;
    private Button chunk30Button;
    private Button chunk60Button;

    private LinearLayout sightContainer;
    private LinearLayout mediaContainer;
    private LinearLayout consecutiveContainer;

    private float sourceTextSizeSp = 20f;
    private long sessionStartMs = 0L;
    private int sessionStartWordCount = 0;
    private SharedPreferences prefs;

    private final Runnable restartRecognition = new Runnable() {
        @Override
        public void run() {
            if (shouldListen && !recognitionInProgress) {
                startRecognitionCycle();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PDFBoxResourceLoader.init(getApplicationContext());
        prefs = getSharedPreferences("interpreter_stats", MODE_PRIVATE);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        buildUi();
        setupAudioDeviceMonitoring();
        refreshHeadsetStatus();
        refreshLanguageButtons();
        refreshModeUi();
        refreshDashboard();

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            recognitionStatus.setText("Speech recognition is not available on this phone.");
            startStopButton.setEnabled(false);
        } else {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(this);
        }

        handleIncomingShare(getIntent());
    }

    private void buildUi() {
        ScrollView pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(true);
        pageScroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(34));
        pageScroll.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(brandRow, matchWrapWithBottomMargin(dp(8)));

        TextView mark = new TextView(this);
        mark.setText("◉");
        mark.setGravity(Gravity.CENTER);
        mark.setTextSize(31);
        mark.setTextColor(GOLD);
        mark.setBackground(rounded(CARD_2, 18));
        brandRow.addView(mark, new LinearLayout.LayoutParams(dp(58), dp(58)));

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams brandTextParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        brandTextParams.setMarginStart(dp(12));
        brandRow.addView(brandText, brandTextParams);

        TextView title = new TextView(this);
        title.setText("Interpreter Trainer");
        title.setTextSize(27);
        title.setTextColor(TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        brandText.addView(title);

        TextView tagline = new TextView(this);
        tagline.setText("Train. Interpret. Improve.");
        tagline.setTextSize(14);
        tagline.setTextColor(GOLD);
        tagline.setPadding(0, dp(3), 0, 0);
        brandText.addView(tagline);

        TextView subtitle = new TextView(this);
        subtitle.setText("Arabic • English • French  |  Sight • Shadowing • Consecutive");
        subtitle.setTextSize(14);
        subtitle.setTextColor(MUTED);
        subtitle.setPadding(0, 0, 0, dp(16));
        root.addView(subtitle);

        LinearLayout dashboard = card();
        root.addView(dashboard, matchWrapWithBottomMargin(dp(15)));
        dashboard.addView(sectionLabel("TRAINING DASHBOARD"));

        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        dashboard.addView(statsRow);
        dashboardSessions = statTile(statsRow, "0", "sessions");
        dashboardMinutes = statTile(statsRow, "0", "minutes");
        dashboardWords = statTile(statsRow, "0", "words");

        dailyGoalLabel = statusText("Daily goal: 0 / 30 min");
        dailyGoalLabel.setPadding(0, dp(14), 0, dp(6));
        dashboard.addView(dailyGoalLabel);
        dailyGoalProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        dailyGoalProgress.setMax(30);
        dailyGoalProgress.setProgress(0);
        if (Build.VERSION.SDK_INT >= 21) {
            dailyGoalProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(GOLD));
            dailyGoalProgress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(CARD_2));
        }
        dashboard.addView(dailyGoalProgress, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(8)));

        LinearLayout statusCard = card();
        root.addView(statusCard, matchWrapWithBottomMargin(dp(15)));
        headsetStatus = statusText("Checking headphones…");
        statusCard.addView(headsetStatus);
        recognitionStatus = statusText("Ready");
        recognitionStatus.setPadding(0, dp(7), 0, 0);
        statusCard.addView(recognitionStatus);
        detectedLanguage = statusText("Detected language: —");
        detectedLanguage.setPadding(0, dp(7), 0, 0);
        statusCard.addView(detectedLanguage);

        root.addView(sectionLabel("TRAINING MODE"));
        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(modeRow, matchWrapWithBottomMargin(dp(16)));
        sightButton = smallButton("Sight");
        shadowingButton = smallButton("Shadowing");
        consecutiveButton = smallButton("Consecutive");
        modeRow.addView(sightButton, weightedButtonParams());
        modeRow.addView(shadowingButton, weightedButtonParamsWithStartMargin());
        modeRow.addView(consecutiveButton, weightedButtonParamsWithStartMargin());
        sightButton.setOnClickListener(v -> setPracticeMode(PracticeMode.SIGHT));
        shadowingButton.setOnClickListener(v -> setPracticeMode(PracticeMode.SHADOWING));
        consecutiveButton.setOnClickListener(v -> setPracticeMode(PracticeMode.CONSECUTIVE));

        root.addView(sectionLabel("TRANSCRIPTION LANGUAGE"));
        LinearLayout langRow1 = new LinearLayout(this);
        langRow1.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(langRow1, matchWrapWithBottomMargin(dp(8)));
        autoButton = smallButton("Auto");
        arabicButton = smallButton("العربية");
        langRow1.addView(autoButton, weightedButtonParams());
        langRow1.addView(arabicButton, weightedButtonParamsWithStartMargin());

        LinearLayout langRow2 = new LinearLayout(this);
        langRow2.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(langRow2, matchWrapWithBottomMargin(dp(17)));
        englishButton = smallButton("English");
        frenchButton = smallButton("Français");
        langRow2.addView(englishButton, weightedButtonParams());
        langRow2.addView(frenchButton, weightedButtonParamsWithStartMargin());
        autoButton.setOnClickListener(v -> setLanguageMode(LanguageMode.AUTO));
        arabicButton.setOnClickListener(v -> setLanguageMode(LanguageMode.ARABIC));
        englishButton.setOnClickListener(v -> setLanguageMode(LanguageMode.ENGLISH));
        frenchButton.setOnClickListener(v -> setLanguageMode(LanguageMode.FRENCH));

        sightContainer = new LinearLayout(this);
        sightContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(sightContainer);
        buildSightSection(sightContainer);

        mediaContainer = new LinearLayout(this);
        mediaContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(mediaContainer);
        buildMediaSection(mediaContainer);

        consecutiveContainer = new LinearLayout(this);
        consecutiveContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(consecutiveContainer);
        buildConsecutiveSection(consecutiveContainer);

        startStopButton = new Button(this);
        startStopButton.setAllCaps(false);
        startStopButton.setText("Start transcription");
        startStopButton.setTextSize(17);
        startStopButton.setTypeface(Typeface.DEFAULT_BOLD);
        startStopButton.setTextColor(BG);
        startStopButton.setBackground(rounded(GOLD, 16));
        root.addView(startStopButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));
        startStopButton.setOnClickListener(v -> toggleListening());

        TextView transcriptLabel = sectionLabel("LIVE TRANSCRIPT");
        transcriptLabel.setPadding(0, dp(22), 0, dp(8));
        root.addView(transcriptLabel);

        LinearLayout transcriptCard = card();
        root.addView(transcriptCard, matchWrapWithBottomMargin(dp(12)));
        ScrollView transcriptScroll = new ScrollView(this);
        transcriptScroll.setFillViewport(true);
        transcriptCard.addView(transcriptScroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(270)));
        LinearLayout transcriptInner = new LinearLayout(this);
        transcriptInner.setOrientation(LinearLayout.VERTICAL);
        transcriptScroll.addView(transcriptInner, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));
        transcriptView = new TextView(this);
        transcriptView.setText("Your interpretation will appear here.");
        transcriptView.setTextSize(19);
        transcriptView.setTextColor(TEXT);
        transcriptView.setLineSpacing(0, 1.25f);
        transcriptView.setTextIsSelectable(true);
        transcriptInner.addView(transcriptView);
        partialView = new TextView(this);
        partialView.setText("");
        partialView.setTextSize(18);
        partialView.setTextColor(MUTED);
        partialView.setPadding(0, dp(12), 0, dp(10));
        transcriptInner.addView(partialView);

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actionRow);
        Button copyButton = smallButton("Copy");
        Button clearButton = smallButton("Clear");
        Button saveButton = smallButton("Save");
        actionRow.addView(copyButton, weightedButtonParams());
        actionRow.addView(clearButton, weightedButtonParamsWithStartMargin());
        actionRow.addView(saveButton, weightedButtonParamsWithStartMargin());
        copyButton.setOnClickListener(v -> copyTranscript());
        clearButton.setOnClickListener(v -> clearTranscript());
        saveButton.setOnClickListener(v -> beginSaveTranscript());

        TextView footer = new TextView(this);
        footer.setText("Document import: PDF, DOCX, TXT, RTF, HTML, CSV, Markdown, JSON, XML and other text-based files. Shadowing and Consecutive modes accept common audio/video files.");
        footer.setTextSize(12);
        footer.setTextColor(MUTED);
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer);

        setContentView(pageScroll);
    }

    private void buildSightSection(LinearLayout parent) {
        parent.addView(sectionLabel("SIGHT TRANSLATION SOURCE"));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(actions, matchWrapWithBottomMargin(dp(8)));
        Button importButton = smallButton("Import document");
        Button pasteButton = smallButton("Paste text");
        Button clearButton = smallButton("Clear");
        actions.addView(importButton, weightedButtonParams());
        actions.addView(pasteButton, weightedButtonParamsWithStartMargin());
        actions.addView(clearButton, weightedButtonParamsWithStartMargin());
        importButton.setOnClickListener(v -> beginOpenDocument());
        pasteButton.setOnClickListener(v -> showPasteTextDialog());
        clearButton.setOnClickListener(v -> clearSourceText());

        LinearLayout fontRow = new LinearLayout(this);
        fontRow.setOrientation(LinearLayout.HORIZONTAL);
        fontRow.setGravity(Gravity.CENTER_VERTICAL);
        parent.addView(fontRow, matchWrapWithBottomMargin(dp(8)));
        sourceFileLabel = statusText("No document loaded");
        fontRow.addView(sourceFileLabel, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button smaller = smallButton("A−");
        Button larger = smallButton("A+");
        fontRow.addView(smaller, new LinearLayout.LayoutParams(dp(66), dp(45)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(66), dp(45));
        lp.setMarginStart(dp(6));
        fontRow.addView(larger, lp);
        smaller.setOnClickListener(v -> adjustSourceTextSize(-2f));
        larger.setOnClickListener(v -> adjustSourceTextSize(2f));

        LinearLayout sourceCard = card();
        parent.addView(sourceCard, matchWrapWithBottomMargin(dp(16)));
        ScrollView sourceScroll = new ScrollView(this);
        sourceScroll.setFillViewport(true);
        sourceCard.addView(sourceScroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(330)));
        sourceTextView = new TextView(this);
        sourceTextView.setText("Import a PDF, Word document or text file, or paste a passage here. Read it while your interpretation is transcribed below.");
        sourceTextView.setTextSize(sourceTextSizeSp);
        sourceTextView.setTextColor(TEXT);
        sourceTextView.setLineSpacing(0, 1.38f);
        sourceTextView.setTextIsSelectable(true);
        sourceScroll.addView(sourceTextView, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));
    }

    private void buildMediaSection(LinearLayout parent) {
        parent.addView(sectionLabel("SOURCE AUDIO / VIDEO"));
        LinearLayout mediaCard = card();
        parent.addView(mediaCard, matchWrapWithBottomMargin(dp(14)));

        mediaFileLabel = new TextView(this);
        mediaFileLabel.setText("No media loaded");
        mediaFileLabel.setTextColor(TEXT);
        mediaFileLabel.setTextSize(16);
        mediaFileLabel.setTypeface(Typeface.DEFAULT_BOLD);
        mediaCard.addView(mediaFileLabel);

        mediaStatus = statusText("Import an audio or video file to begin.");
        mediaStatus.setPadding(0, dp(6), 0, dp(12));
        mediaCard.addView(mediaStatus);

        Button importMedia = smallButton("Import audio / video");
        mediaCard.addView(importMedia, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));
        importMedia.setOnClickListener(v -> beginOpenMedia());

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(0, dp(10), 0, 0);
        mediaCard.addView(controls);
        playPauseMediaButton = smallButton("Play");
        Button restartMediaButton = smallButton("Restart");
        controls.addView(playPauseMediaButton, weightedButtonParams());
        controls.addView(restartMediaButton, weightedButtonParamsWithStartMargin());
        playPauseMediaButton.setOnClickListener(v -> toggleMediaPlayback());
        restartMediaButton.setOnClickListener(v -> restartMedia());

        TextView speedLabel = statusText("Playback speed");
        speedLabel.setPadding(0, dp(12), 0, dp(7));
        mediaCard.addView(speedLabel);
        LinearLayout speeds = new LinearLayout(this);
        speeds.setOrientation(LinearLayout.HORIZONTAL);
        mediaCard.addView(speeds);
        speed075Button = smallButton("0.75×");
        speed100Button = smallButton("1.0×");
        speed125Button = smallButton("1.25×");
        speeds.addView(speed075Button, weightedButtonParams());
        speeds.addView(speed100Button, weightedButtonParamsWithStartMargin());
        speeds.addView(speed125Button, weightedButtonParamsWithStartMargin());
        speed075Button.setOnClickListener(v -> setPlaybackSpeed(0.75f));
        speed100Button.setOnClickListener(v -> setPlaybackSpeed(1.0f));
        speed125Button.setOnClickListener(v -> setPlaybackSpeed(1.25f));
        refreshSpeedButtons();
    }

    private void buildConsecutiveSection(LinearLayout parent) {
        parent.addView(sectionLabel("CONSECUTIVE WORKFLOW"));
        LinearLayout card = card();
        parent.addView(card, matchWrapWithBottomMargin(dp(14)));

        TextView help = statusText("Choose a segment length. Play one segment, take notes, then interpret it aloud. The next segment starts where the previous one stopped.");
        help.setPadding(0, 0, 0, dp(10));
        card.addView(help);

        LinearLayout chunks = new LinearLayout(this);
        chunks.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(chunks);
        chunk15Button = smallButton("15 sec");
        chunk30Button = smallButton("30 sec");
        chunk60Button = smallButton("60 sec");
        chunks.addView(chunk15Button, weightedButtonParams());
        chunks.addView(chunk30Button, weightedButtonParamsWithStartMargin());
        chunks.addView(chunk60Button, weightedButtonParamsWithStartMargin());
        chunk15Button.setOnClickListener(v -> setChunkSeconds(15));
        chunk30Button.setOnClickListener(v -> setChunkSeconds(30));
        chunk60Button.setOnClickListener(v -> setChunkSeconds(60));
        refreshChunkButtons();

        Button playSegmentButton = smallButton("Play next segment");
        LinearLayout.LayoutParams playParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        playParams.topMargin = dp(10);
        card.addView(playSegmentButton, playParams);
        playSegmentButton.setOnClickListener(v -> playConsecutiveSegment());

        TextView notesLabel = statusText("Notes");
        notesLabel.setPadding(0, dp(12), 0, dp(7));
        card.addView(notesLabel);
        consecutiveNotes = new EditText(this);
        consecutiveNotes.setHint("Type your interpreting notes here…");
        consecutiveNotes.setHintTextColor(Color.rgb(115, 128, 153));
        consecutiveNotes.setTextColor(TEXT);
        consecutiveNotes.setTextSize(16);
        consecutiveNotes.setGravity(Gravity.TOP | Gravity.START);
        consecutiveNotes.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        consecutiveNotes.setMinLines(5);
        consecutiveNotes.setPadding(dp(12), dp(10), dp(12), dp(10));
        consecutiveNotes.setBackground(rounded(CARD_2, 12));
        card.addView(consecutiveNotes, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(16), dp(15), dp(16), dp(15));
        GradientDrawable bg = rounded(CARD, 18);
        bg.setStroke(dp(1), Color.rgb(47, 61, 91));
        layout.setBackground(bg);
        return layout;
    }

    private TextView sectionLabel(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(12);
        view.setTextColor(GOLD);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setPadding(0, 0, 0, dp(8));
        return view;
    }

    private TextView statusText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(14);
        view.setTextColor(MUTED);
        return view;
    }

    private TextView statTile(LinearLayout parent, String value, String label) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(6), dp(8), dp(6), dp(8));
        tile.setBackground(rounded(CARD_2, 13));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(70), 1f);
        if (parent.getChildCount() > 0) p.setMarginStart(dp(7));
        parent.addView(tile, p);
        TextView number = new TextView(this);
        number.setText(value);
        number.setTextColor(TEXT);
        number.setTextSize(21);
        number.setTypeface(Typeface.DEFAULT_BOLD);
        number.setGravity(Gravity.CENTER);
        tile.addView(number);
        TextView small = new TextView(this);
        small.setText(label);
        small.setTextColor(MUTED);
        small.setTextSize(11);
        small.setGravity(Gravity.CENTER);
        tile.addView(small);
        return number;
    }

    private Button smallButton(String text) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(text);
        button.setTextSize(13);
        button.setTextColor(TEXT);
        button.setBackground(rounded(CARD_2, 13));
        button.setPadding(dp(6), dp(7), dp(6), dp(7));
        return button;
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        return new LinearLayout.LayoutParams(0, dp(50), 1f);
    }

    private LinearLayout.LayoutParams weightedButtonParamsWithStartMargin() {
        LinearLayout.LayoutParams params = weightedButtonParams();
        params.setMarginStart(dp(7));
        return params;
    }

    private LinearLayout.LayoutParams matchWrapWithBottomMargin(int bottomMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = bottomMargin;
        return params;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void setPracticeMode(PracticeMode mode) {
        if (practiceMode == mode) return;
        if (shouldListen) stopListening();
        if (practiceMode != PracticeMode.SIGHT && mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            if (playPauseMediaButton != null) playPauseMediaButton.setText("Play");
        }
        practiceMode = mode;
        refreshModeUi();
    }

    private void refreshModeUi() {
        styleModeButton(sightButton, practiceMode == PracticeMode.SIGHT);
        styleModeButton(shadowingButton, practiceMode == PracticeMode.SHADOWING);
        styleModeButton(consecutiveButton, practiceMode == PracticeMode.CONSECUTIVE);
        if (sightContainer != null) sightContainer.setVisibility(practiceMode == PracticeMode.SIGHT ? View.VISIBLE : View.GONE);
        if (mediaContainer != null) mediaContainer.setVisibility(practiceMode == PracticeMode.SIGHT ? View.GONE : View.VISIBLE);
        if (consecutiveContainer != null) consecutiveContainer.setVisibility(practiceMode == PracticeMode.CONSECUTIVE ? View.VISIBLE : View.GONE);
        if (recognitionStatus != null) {
            if (practiceMode == PracticeMode.SIGHT) recognitionStatus.setText("Sight mode ready");
            else if (practiceMode == PracticeMode.SHADOWING) recognitionStatus.setText("Shadowing mode ready");
            else recognitionStatus.setText("Consecutive mode ready");
        }
    }

    private void setLanguageMode(LanguageMode mode) {
        languageMode = mode;
        detectedLanguage.setText("Detected language: —");
        refreshLanguageButtons();
        if (shouldListen) {
            if (speechRecognizer != null) speechRecognizer.cancel();
            recognitionInProgress = false;
            handler.removeCallbacks(restartRecognition);
            handler.postDelayed(restartRecognition, 250);
        }
    }

    private void refreshLanguageButtons() {
        styleModeButton(autoButton, languageMode == LanguageMode.AUTO);
        styleModeButton(arabicButton, languageMode == LanguageMode.ARABIC);
        styleModeButton(englishButton, languageMode == LanguageMode.ENGLISH);
        styleModeButton(frenchButton, languageMode == LanguageMode.FRENCH);
    }

    private void styleModeButton(Button button, boolean selected) {
        if (button == null) return;
        if (selected) {
            button.setTextColor(BG);
            button.setTypeface(Typeface.DEFAULT_BOLD);
            button.setBackground(rounded(GOLD, 13));
        } else {
            button.setTextColor(TEXT);
            button.setTypeface(Typeface.DEFAULT);
            button.setBackground(rounded(CARD_2, 13));
        }
    }

    private void showPasteTextDialog() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setMinLines(10);
        input.setTextSize(18);
        input.setHint("Paste Arabic, English or French text here…");
        String current = sourceTextView == null ? "" : sourceTextView.getText().toString();
        if (!current.startsWith("Import a PDF")) input.setText(current);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Practice text")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Use text", (d, which) -> {
                    String text = input.getText().toString().trim();
                    if (!text.isEmpty()) {
                        sourceTextView.setText(text);
                        sourceFileLabel.setText("Pasted text");
                    }
                }).create();
        dialog.show();
    }

    private void beginOpenDocument() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        String[] types = new String[]{
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "text/plain", "text/rtf", "text/html", "text/csv",
                "application/json", "application/xml", "text/xml", "text/markdown"
        };
        intent.putExtra(Intent.EXTRA_MIME_TYPES, types);
        startActivityForResult(intent, REQUEST_OPEN_DOCUMENT);
    }

    private void beginOpenMedia() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
        startActivityForResult(intent, REQUEST_OPEN_MEDIA);
    }

    private void clearSourceText() {
        sourceTextView.setText("Import a PDF, Word document or text file, or paste a passage here. Read it while your interpretation is transcribed below.");
        sourceFileLabel.setText("No document loaded");
    }

    private void adjustSourceTextSize(float deltaSp) {
        sourceTextSizeSp = Math.max(14f, Math.min(36f, sourceTextSizeSp + deltaSp));
        sourceTextView.setTextSize(sourceTextSizeSp);
    }

    private String displayName(Uri uri) {
        if (uri == null) return "document";
        String name = null;
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = cursor.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        if (name == null || name.trim().isEmpty()) name = uri.getLastPathSegment();
        return name == null ? "document" : name;
    }

    private void loadDocumentFromUri(Uri uri) {
        if (uri == null) return;
        String name = displayName(uri);
        String lower = name.toLowerCase(Locale.ROOT);
        String mime = getContentResolver().getType(uri);
        try {
            String text;
            if (lower.endsWith(".pdf") || "application/pdf".equals(mime)) {
                text = readPdf(uri);
            } else if (lower.endsWith(".docx") || "application/vnd.openxmlformats-officedocument.wordprocessingml.document".equals(mime)) {
                text = readDocx(uri);
            } else if (lower.endsWith(".rtf") || "text/rtf".equals(mime) || "application/rtf".equals(mime)) {
                text = readRtf(uri);
            } else if (lower.endsWith(".html") || lower.endsWith(".htm") || "text/html".equals(mime)) {
                text = readHtml(uri);
            } else {
                text = readPlainText(uri);
            }

            text = normalizeDocumentText(text);
            if (text.length() > 600000) {
                text = text.substring(0, 600000) + "\n\n[Document shortened for performance]";
            }
            if (text.trim().isEmpty()) {
                Toast.makeText(this, "No readable text was found in this file.", Toast.LENGTH_LONG).show();
                return;
            }
            sourceTextView.setText(text);
            sourceFileLabel.setText(name);
            Toast.makeText(this, "Document loaded: " + name, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not read this document: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private String readPdf(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             PDDocument document = in == null ? null : PDDocument.load(in)) {
            if (document == null) return "";
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(document);
        }
    }

    private String readDocx(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             ZipInputStream zip = in == null ? null : new ZipInputStream(in)) {
            if (zip == null) return "";
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if ("word/document.xml".equals(entry.getName())) {
                    String xml = new String(readAllBytes(zip), StandardCharsets.UTF_8);
                    xml = xml.replaceAll("(?i)<w:tab[^>]*/>", "\t");
                    xml = xml.replaceAll("(?i)<w:br[^>]*/>", "\n");
                    xml = xml.replaceAll("(?i)</w:p>", "\n");
                    xml = xml.replaceAll("(?i)</w:tr>", "\n");
                    xml = xml.replaceAll("(?i)</w:tc>", "\t");
                    xml = xml.replaceAll("<[^>]+>", "");
                    return decodeXmlEntities(xml);
                }
            }
        }
        return "";
    }

    private String readRtf(Uri uri) throws Exception {
        String raw = readPlainText(uri);
        String text = raw.replaceAll("\\\\par[d]?", "\n")
                .replaceAll("\\\\tab", "\t")
                .replaceAll("\\\\'[0-9a-fA-F]{2}", "")
                .replaceAll("\\\\[a-zA-Z]+-?\\d* ?", "")
                .replaceAll("[{}]", "");
        return text;
    }

    private String readHtml(Uri uri) throws Exception {
        String raw = readPlainText(uri);
        if (Build.VERSION.SDK_INT >= 24) {
            return Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY).toString();
        }
        return Html.fromHtml(raw).toString();
    }

    private String readPlainText(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader reader = in == null ? null : new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            if (reader == null) return "";
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                if (out.length() > 0) out.append('\n');
                out.append(line);
                if (out.length() > 650000) break;
            }
            return out.toString();
        }
    }

    private byte[] readAllBytes(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    private String decodeXmlEntities(String text) {
        return text.replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'");
    }

    private String normalizeDocumentText(String text) {
        if (text == null) return "";
        return text.replace("\r\n", "\n")
                .replace('\r', '\n')
                .replaceAll("[ \\t]+\\n", "\n")
                .replaceAll("\\n{4,}", "\n\n\n")
                .trim();
    }

    private void handleIncomingShare(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (sharedText != null && !sharedText.trim().isEmpty() && sourceTextView != null) {
                sourceTextView.setText(sharedText.trim());
                sourceFileLabel.setText("Shared text");
                return;
            }
            Uri stream = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (stream != null && sourceTextView != null) {
                loadDocumentFromUri(stream);
            }
        }
    }

    private void loadMedia(Uri uri) {
        if (uri == null) return;
        releaseMediaPlayer();
        mediaUri = uri;
        mediaFileLabel.setText(displayName(uri));
        mediaStatus.setText("Preparing media…");
        mediaPrepared = false;
        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(this, uri);
            mediaPlayer.setOnPreparedListener(mp -> {
                mediaPrepared = true;
                mediaStatus.setText("Ready • " + formatDuration(mp.getDuration()));
                playPauseMediaButton.setText("Play");
                applyPlaybackSpeed();
            });
            mediaPlayer.setOnCompletionListener(mp -> {
                playPauseMediaButton.setText("Play");
                mediaStatus.setText("Finished");
            });
            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                mediaStatus.setText("Could not play this file.");
                return true;
            });
            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            mediaStatus.setText("Media error: " + safeMessage(e));
        }
    }

    private void toggleMediaPlayback() {
        if (!mediaPrepared || mediaPlayer == null) {
            Toast.makeText(this, "Import a media file first.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                playPauseMediaButton.setText("Play");
                mediaStatus.setText("Paused at " + formatDuration(mediaPlayer.getCurrentPosition()));
            } else {
                applyPlaybackSpeed();
                mediaPlayer.start();
                playPauseMediaButton.setText("Pause");
                mediaStatus.setText("Playing • " + playbackSpeed + "×");
            }
        } catch (Exception e) {
            mediaStatus.setText("Playback error: " + safeMessage(e));
        }
    }

    private void restartMedia() {
        if (!mediaPrepared || mediaPlayer == null) return;
        try {
            mediaPlayer.seekTo(0);
            mediaStatus.setText("Restarted");
        } catch (Exception ignored) { }
    }

    private void setPlaybackSpeed(float speed) {
        playbackSpeed = speed;
        refreshSpeedButtons();
        applyPlaybackSpeed();
    }

    private void applyPlaybackSpeed() {
        if (!mediaPrepared || mediaPlayer == null || Build.VERSION.SDK_INT < 23) return;
        try {
            android.media.PlaybackParams params = mediaPlayer.getPlaybackParams();
            params.setSpeed(playbackSpeed);
            mediaPlayer.setPlaybackParams(params);
        } catch (Exception ignored) { }
    }

    private void refreshSpeedButtons() {
        styleModeButton(speed075Button, Math.abs(playbackSpeed - 0.75f) < 0.01f);
        styleModeButton(speed100Button, Math.abs(playbackSpeed - 1.0f) < 0.01f);
        styleModeButton(speed125Button, Math.abs(playbackSpeed - 1.25f) < 0.01f);
    }

    private void setChunkSeconds(int seconds) {
        consecutiveChunkSeconds = seconds;
        refreshChunkButtons();
    }

    private void refreshChunkButtons() {
        styleModeButton(chunk15Button, consecutiveChunkSeconds == 15);
        styleModeButton(chunk30Button, consecutiveChunkSeconds == 30);
        styleModeButton(chunk60Button, consecutiveChunkSeconds == 60);
    }

    private void playConsecutiveSegment() {
        if (!mediaPrepared || mediaPlayer == null) {
            Toast.makeText(this, "Import source audio/video first.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (pauseMediaRunnable != null) handler.removeCallbacks(pauseMediaRunnable);
        try {
            if (shouldListen) stopListening();
            applyPlaybackSpeed();
            mediaPlayer.start();
            playPauseMediaButton.setText("Pause");
            mediaStatus.setText("Listening segment: " + consecutiveChunkSeconds + " sec");
            pauseMediaRunnable = () -> {
                try {
                    if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                        playPauseMediaButton.setText("Play");
                        mediaStatus.setText("Segment complete • interpret now");
                    }
                } catch (Exception ignored) { }
            };
            handler.postDelayed(pauseMediaRunnable, consecutiveChunkSeconds * 1000L);
        } catch (Exception e) {
            mediaStatus.setText("Segment error: " + safeMessage(e));
        }
    }

    private String formatDuration(int millis) {
        int total = Math.max(0, millis / 1000);
        return String.format(Locale.US, "%d:%02d", total / 60, total % 60);
    }

    private void toggleListening() {
        if (shouldListen) stopListening();
        else ensurePermissionAndStart();
    }

    private void ensurePermissionAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
        }
    }

    private void startListening() {
        if (speechRecognizer == null) return;
        shouldListen = true;
        sessionStartMs = System.currentTimeMillis();
        sessionStartWordCount = countWords(committedText.toString());
        startStopButton.setText("Stop transcription");
        startStopButton.setTextColor(TEXT);
        startStopButton.setBackground(rounded(RED, 16));
        recognitionStatus.setText("Starting microphone…");
        handler.removeCallbacks(restartRecognition);
        startRecognitionCycle();
    }

    private void stopListening() {
        shouldListen = false;
        recognitionInProgress = false;
        handler.removeCallbacks(restartRecognition);
        if (speechRecognizer != null) {
            try { speechRecognizer.stopListening(); } catch (Exception ignored) { }
        }
        partialView.setText("");
        recognitionStatus.setText("Paused");
        startStopButton.setText("Start transcription");
        startStopButton.setTextColor(BG);
        startStopButton.setBackground(rounded(GOLD, 16));
        finishSessionTracking();
    }

    private void startRecognitionCycle() {
        if (!shouldListen || speechRecognizer == null || recognitionInProgress) return;
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        if (Build.VERSION.SDK_INT >= 33) {
            intent.putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING, RecognizerIntent.FORMATTING_OPTIMIZE_LATENCY);
            intent.putExtra(RecognizerIntent.EXTRA_HIDE_PARTIAL_TRAILING_PUNCTUATION, true);
        }
        if (languageMode == LanguageMode.ARABIC) {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-MA");
        } else if (languageMode == LanguageMode.ENGLISH) {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        } else if (languageMode == LanguageMode.FRENCH) {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        } else {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-MA");
            if (Build.VERSION.SDK_INT >= 34) {
                ArrayList<String> languages = new ArrayList<>();
                languages.add("ar-MA");
                languages.add("en-US");
                languages.add("fr-FR");
                intent.putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION, true);
                intent.putStringArrayListExtra(RecognizerIntent.EXTRA_LANGUAGE_DETECTION_ALLOWED_LANGUAGES, languages);
                intent.putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_SWITCH, RecognizerIntent.LANGUAGE_SWITCH_BALANCED);
                intent.putStringArrayListExtra(RecognizerIntent.EXTRA_LANGUAGE_SWITCH_ALLOWED_LANGUAGES, languages);
            }
        }
        try {
            recognitionInProgress = true;
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            recognitionInProgress = false;
            recognitionStatus.setText("Could not start recognition: " + safeMessage(e));
            scheduleRestart(700);
        }
    }

    private void scheduleRestart(long delayMs) {
        if (!shouldListen) return;
        handler.removeCallbacks(restartRecognition);
        handler.postDelayed(restartRecognition, delayMs);
    }

    private void appendFinalText(String text) {
        if (text == null || text.trim().isEmpty()) return;
        if (committedText.length() > 0) committedText.append('\n');
        committedText.append(text.trim());
        transcriptView.setText(committedText.toString());
        partialView.setText("");
    }

    private void clearTranscript() {
        committedText.setLength(0);
        transcriptView.setText("Your interpretation will appear here.");
        partialView.setText("");
    }

    private void copyTranscript() {
        if (committedText.length() == 0) {
            Toast.makeText(this, "Nothing to copy yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Transcript", committedText.toString()));
        Toast.makeText(this, "Transcript copied.", Toast.LENGTH_SHORT).show();
    }

    private void beginSaveTranscript() {
        if (committedText.length() == 0) {
            Toast.makeText(this, "Nothing to save yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "interpreter_" + practiceMode.name().toLowerCase(Locale.ROOT) + "_" + stamp + ".txt");
        startActivityForResult(intent, REQUEST_SAVE_FILE);
    }

    private int countWords(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        return text.trim().split("\\s+").length;
    }

    private void finishSessionTracking() {
        if (sessionStartMs <= 0L) return;
        long elapsed = Math.max(0L, System.currentTimeMillis() - sessionStartMs);
        int words = Math.max(0, countWords(committedText.toString()) - sessionStartWordCount);
        if (elapsed >= 3000L) {
            SharedPreferences.Editor ed = prefs.edit();
            ed.putLong("total_ms", prefs.getLong("total_ms", 0L) + elapsed);
            ed.putInt("total_words", prefs.getInt("total_words", 0) + words);
            String key = practiceMode == PracticeMode.SIGHT ? "count_sight" :
                    practiceMode == PracticeMode.SHADOWING ? "count_shadow" : "count_consecutive";
            ed.putInt(key, prefs.getInt(key, 0) + 1);
            ed.apply();
        }
        sessionStartMs = 0L;
        refreshDashboard();
    }

    private void refreshDashboard() {
        if (prefs == null || dashboardSessions == null) return;
        int sight = prefs.getInt("count_sight", 0);
        int shadow = prefs.getInt("count_shadow", 0);
        int consecutive = prefs.getInt("count_consecutive", 0);
        int sessions = sight + shadow + consecutive;
        long minutes = prefs.getLong("total_ms", 0L) / 60000L;
        int words = prefs.getInt("total_words", 0);
        dashboardSessions.setText(String.valueOf(sessions));
        dashboardMinutes.setText(String.valueOf(minutes));
        dashboardWords.setText(String.valueOf(words));
        int progress = (int) Math.min(30, minutes);
        dailyGoalProgress.setProgress(progress);
        dailyGoalLabel.setText("Practice goal: " + Math.min(minutes, 30) + " / 30 min");
    }

    private String safeMessage(Exception e) {
        String msg = e.getMessage();
        return (msg == null || msg.trim().isEmpty()) ? e.getClass().getSimpleName() : msg;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OPEN_DOCUMENT && resultCode == RESULT_OK && data != null) {
            loadDocumentFromUri(data.getData());
            return;
        }
        if (requestCode == REQUEST_OPEN_MEDIA && resultCode == RESULT_OK && data != null) {
            loadMedia(data.getData());
            return;
        }
        if (requestCode == REQUEST_SAVE_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
                if (stream != null) {
                    StringBuilder out = new StringBuilder();
                    out.append("Mode: ").append(practiceMode.name()).append("\n");
                    out.append("Language: ").append(languageMode.name()).append("\n");
                    out.append("Saved: ").append(new Date()).append("\n\n");
                    if (practiceMode == PracticeMode.CONSECUTIVE && consecutiveNotes != null && consecutiveNotes.length() > 0) {
                        out.append("NOTES\n").append(consecutiveNotes.getText()).append("\n\n");
                    }
                    out.append("TRANSCRIPT\n").append(committedText);
                    stream.write(out.toString().getBytes(StandardCharsets.UTF_8));
                    stream.flush();
                    Toast.makeText(this, "Session saved.", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Save failed: " + safeMessage(e), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void setupAudioDeviceMonitoring() {
        if (Build.VERSION.SDK_INT >= 23) {
            audioDeviceCallback = new AudioDeviceCallback() {
                @Override public void onAudioDevicesAdded(AudioDeviceInfo[] addedDevices) { refreshHeadsetStatus(); }
                @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] removedDevices) { refreshHeadsetStatus(); }
            };
        }
    }

    private void refreshHeadsetStatus() {
        if (audioManager == null || headsetStatus == null) return;
        AudioDeviceInfo[] devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
        String detected = null;
        for (AudioDeviceInfo device : devices) {
            switch (device.getType()) {
                case AudioDeviceInfo.TYPE_WIRED_HEADPHONES: detected = "Wired headphones"; break;
                case AudioDeviceInfo.TYPE_WIRED_HEADSET: detected = "Wired headset"; break;
                case AudioDeviceInfo.TYPE_USB_HEADSET: detected = "USB headset"; break;
                case AudioDeviceInfo.TYPE_BLUETOOTH_A2DP:
                case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: detected = "Bluetooth headphones"; break;
                default:
                    if (Build.VERSION.SDK_INT >= 31 &&
                            (device.getType() == AudioDeviceInfo.TYPE_BLE_HEADSET || device.getType() == AudioDeviceInfo.TYPE_BLE_SPEAKER)) {
                        detected = "Bluetooth LE audio";
                    }
            }
            if (detected != null) break;
        }
        headsetStatus.setText(detected == null ? "Headphones: not detected (app still works)" : "Headphones: " + detected + " connected");
    }

    private void releaseMediaPlayer() {
        if (pauseMediaRunnable != null) handler.removeCallbacks(pauseMediaRunnable);
        pauseMediaRunnable = null;
        if (mediaPlayer != null) {
            try { mediaPlayer.release(); } catch (Exception ignored) { }
            mediaPlayer = null;
        }
        mediaPrepared = false;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (audioManager != null && audioDeviceCallback != null && !audioCallbackRegistered) {
            audioManager.registerAudioDeviceCallback(audioDeviceCallback, handler);
            audioCallbackRegistered = true;
        }
        refreshHeadsetStatus();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (audioManager != null && audioDeviceCallback != null && audioCallbackRegistered) {
            audioManager.unregisterAudioDeviceCallback(audioDeviceCallback);
            audioCallbackRegistered = false;
        }
    }

    @Override
    protected void onDestroy() {
        if (shouldListen) finishSessionTracking();
        shouldListen = false;
        handler.removeCallbacksAndMessages(null);
        releaseMediaPlayer();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startListening();
            } else {
                recognitionStatus.setText("Microphone permission is required.");
                if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                    Toast.makeText(this, "Enable Microphone permission in Settings.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                }
            }
        }
    }

    @Override public void onReadyForSpeech(Bundle params) { recognitionStatus.setText("Listening… speak now"); }
    @Override public void onBeginningOfSpeech() { recognitionStatus.setText("Transcribing…"); }
    @Override public void onRmsChanged(float rmsdB) { }
    @Override public void onBufferReceived(byte[] buffer) { }
    @Override public void onEndOfSpeech() { recognitionStatus.setText("Processing…"); }

    @Override
    public void onError(int error) {
        recognitionInProgress = false;
        if (!shouldListen) return;
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            recognitionStatus.setText("Microphone permission is required.");
            shouldListen = false;
            startStopButton.setText("Start transcription");
            return;
        }
        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            recognitionStatus.setText("Listening…");
            scheduleRestart(250);
            return;
        }
        recognitionStatus.setText("Recognizer reconnecting… (" + errorName(error) + ")");
        scheduleRestart(700);
    }

    @Override
    public void onResults(Bundle results) {
        recognitionInProgress = false;
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) appendFinalText(matches.get(0));
        recognitionStatus.setText("Listening…");
        scheduleRestart(250);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) partialView.setText(matches.get(0));
    }

    @Override public void onEvent(int eventType, Bundle params) { }
    @Override public void onSegmentResults(Bundle segmentResults) { }
    @Override public void onEndOfSegmentedSession() { }

    @Override
    public void onLanguageDetection(Bundle results) {
        if (Build.VERSION.SDK_INT < 34 || results == null) return;
        String language = results.getString(SpeechRecognizer.DETECTED_LANGUAGE);
        if (language == null || language.isEmpty()) return;
        String lower = language.toLowerCase(Locale.ROOT);
        String friendly = lower.startsWith("ar") ? "Arabic (" + language + ")" :
                lower.startsWith("en") ? "English (" + language + ")" :
                lower.startsWith("fr") ? "French (" + language + ")" : language;
        detectedLanguage.setText("Detected language: " + friendly);
    }

    private String errorName(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "audio error";
            case SpeechRecognizer.ERROR_CLIENT: return "client error";
            case SpeechRecognizer.ERROR_NETWORK: return "network error";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "network timeout";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "recognizer busy";
            case SpeechRecognizer.ERROR_SERVER: return "server error";
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED: return "server disconnected";
            case SpeechRecognizer.ERROR_TOO_MANY_REQUESTS: return "too many requests";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: return "language not supported";
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: return "language unavailable";
            default: return "error " + error;
        }
    }
}
