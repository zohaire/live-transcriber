# Interpreter Trainer V4

Repository replacement specification for the new interpreter training application.
