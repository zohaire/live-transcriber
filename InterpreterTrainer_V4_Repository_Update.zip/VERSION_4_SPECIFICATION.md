# Interpreter Trainer App - Version 4

## Goal
Transform LiveTranscriber into a professional but simple interpreter training app.

## Branding
- Replace app identity with the provided microphone/signal logo.
- Use it for launcher icon and splash screen.
- Blue and white professional theme.

## Main Navigation
- Home
- Practice
- Progress
- Settings

## Modes

### Shadowing
- Play source audio.
- Transcribe the speaker live while audio plays.
- Record user's shadowing voice separately.
- Display source transcript and user transcript.

### Sight Translation
- Import PDF, DOCX, TXT and image documents.
- Display source text.
- Timer.
- Live transcription of interpretation.

### Consecutive
- Play speech.
- Pause.
- Notes area.
- Record interpretation.
- Generate transcript.

## Languages
- Arabic
- English
- French
- Auto detection

## Design
- Simpler screens.
- Large buttons.
- Smooth navigation.
- Lower battery usage.
- Faster startup.

## Future
- Scoring.
- Accuracy analysis.
- Terminology feedback.
