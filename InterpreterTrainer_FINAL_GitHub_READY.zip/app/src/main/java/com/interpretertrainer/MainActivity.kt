package com.interpretertrainer

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val t = TextView(this)
  t.text = "Interpreter Trainer\n\nSight Translation\nShadowing\nConsecutive Interpretation"
  setContentView(t)
 }
}
