package com.interpretertrainer

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val tv = TextView(this)
  tv.text = "Interpreter Trainer\n\nSight Translation\nShadowing\nConsecutive Interpretation\n\nV1 Build Test"
  setContentView(tv)
 }
}