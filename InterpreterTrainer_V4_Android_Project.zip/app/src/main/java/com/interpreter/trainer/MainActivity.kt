package com.interpreter.trainer

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val view = TextView(this)
  view.text = "Interpreter Trainer V4\n\nShadowing\nSight Translation\nConsecutive Interpretation"
  view.textSize = 22f
  setContentView(view)
 }
}
