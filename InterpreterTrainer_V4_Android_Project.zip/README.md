# Interpreter Trainer V4 Android Project

Real Android project structure for GitHub Actions build.

Features planned:
- Shadowing mode
- Sight translation mode
- Consecutive mode
- Arabic/English/French support
- Document import architecture
- New logo integration
